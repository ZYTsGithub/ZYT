var searchinput = document.getElementById("sousuoinput")
var searchbtn = document.getElementById("sousuobtn")
var songslistul=document.getElementsByClassName("songslist")[0]
var songslistdiv=document.getElementsByClassName("songslistdiv")[0]
var musicaudio=document.getElementById("musicaudio")
var  geciul=document.getElementsByClassName("geciul")[0]



var quanjucicidujixiang=[]
var get = function(url, data, callback) {
	var xhr = new XMLHttpRequest()
	var str = "?"
	for(var key in data) {
		str += key + "=" + data[key] + "&"
	}
	//		console.log(str)
	//		str.slice(0,str.length-1)
	url += str.slice(0, str.length - 1)
	xhr.open("GET", url, true)
	xhr.send()
	xhr.onreadystatechange = function() {
		if(xhr.status == 200 && xhr.readyState == 4) {
			//			xhr.response
			callback(JSON.parse(xhr.response))
		}
	}
}

var search = function(keyswordssss, callback) {
	get("http://localhost:3000/search", {keywords: keyswordssss}, function(res) {
		console.log(res.result.songs)
		if(callback) {
			callback(res.result.songs)
		}
	})
}


var geturl=function(idnum,callback){
	get("http://localhost:3000/song/url",{id:idnum},function(res){
		console.log(res.data[0].url)
		if(callback) {
			callback(res.data[0].url)
		}
	})
}

//填充
var fiilyc=function(arrgeci){
	var strgeci=""
	var tmpgeci='<li class="meiyiju">lall</li>'
	for(var i=0;i<arrgeci.length;i++){
		strgeci+=tmpgeci.replace("lall",arrgeci[i].content)
		
	}
	geciul.innerHTML=strgeci
	
}
//解析
var parselyc=function(lycstr){
	
	var chulishijian=function(shijian){
		var sec=0
	 	var shijianfenkaishuzu= shijian.split(":")
	 	sec=parseInt(shijianfenkaishuzu[0])*60+ parseFloat(shijianfenkaishuzu[1]) 
		return sec
	}
	var  geciarr=[]
	var geciobjarr=[]
	geciarr=lycstr.split("\n")
	console.log(geciarr)

	for(var i=0;i<geciarr.length;i++){
		var lines=[]
		lines=geciarr[i].split("]")
		
		var time=lines[0].slice(1,lines[0].length)
		console.log(time)
		
		var content=lines[1]
		var shijian=chulishijian(time)
		if(isNaN(shijian)) continue;
		geciobjarr.push({
			time:shijian,
			content:content
		})
		
	}
	console.log(geciobjarr)
	quanjucicidujixiang=geciobjarr
	return geciobjarr
}
//得到歌词
var getlyc=function(idnumberr,callback){
	get("http://localhost:3000/lyric",{id:idnumberr},function(res){
		var gecineir=res.lrc.lyric
//		gecineir.split("\n")
		if(callback){
			callback(gecineir)
		}
	})
}

//getlyc(1323304355,function(gecistr){
//	
//})



searchbtn.addEventListener("click",function(){
	
	var val = searchinput.value
	search(val, function(songs) {
		var songsstr = ""
		var songstmp = '<li data-id="1231" class="song">' +
			'<h1>lalallla</h1>' +
			'<h4><span>singer</span>-专辑<span>zhaunjiming</span></h4>' +
			'<hr />' +
			'</li>'
		for(var i = 0; i < songs.length; i++) {
			songsstr += songstmp.replace("lalallla", songs[i].name)
				.replace('singer', songs[i].artists[0].name)
				.replace('zhaunjiming', songs[i].album.name)
				.replace("1231",songs[i].id)
		}
		songslistul.innerHTML=songsstr
		songslistdiv.className="songslistdiv active"
		var songsli=document.getElementsByClassName("song")
		for(var i=0;i<songsli.length;i++){
			songsli[i].addEventListener("click",function(){
				var thisid=this.getAttribute("data-id")
				geturl(thisid,function(url){
					musicaudio.src=url
					musicaudio.play()
					
				})
				getlyc(thisid,function(strgeci){
					var geciduixiangshuzu=parselyc(strgeci)
					console.log(geciduixiangshuzu)
					fiilyc(geciduixiangshuzu)
				})
				console.log(122)
				songslistdiv.className="songslistdiv"
				
		})
		}
		
	})
})
var index=0
musicaudio.addEventListener("timeupdate",function(){
	var meiyijugeci=document.getElementsByClassName("meiyiju")
	for(var i=0;i<quanjucicidujixiang.length;i++){
		if(Math.abs(quanjucicidujixiang[i].time-musicaudio.currentTime)<0.3){
			meiyijugeci[i].style.color="white"
			if(index>0){
				meiyijugeci[i-1].style.color="black"
			}
			
			index++
		}
	}
})

