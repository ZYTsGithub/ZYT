var get=function(method,url,data,callback){
	var xhr = new XMLHttpRequest();
	if(method.toLocaleUpperCase()=="GET"){
		
//		console.log(url)
		
	}
	xhr.open(method,url,true)
	
}
